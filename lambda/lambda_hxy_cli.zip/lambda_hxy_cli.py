def handler(event, context):
    a = 'this is lambda from cli'
    return print(a)


